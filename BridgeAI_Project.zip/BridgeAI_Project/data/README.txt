The application creates student_profile.json here when a profile is saved. Do not upload personal profile data unless required and approved.
