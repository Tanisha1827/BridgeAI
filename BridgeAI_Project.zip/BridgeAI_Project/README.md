# BridgeAI — Student Skill-Gap & Career Pathway Companion

## Project contents
This submission contains one Streamlit application, six learning modules, automated unit tests, a project report, a presentation, and 11 screenshots.

## Run on Windows
1. Extract the ZIP.
2. Open Anaconda Prompt or Command Prompt and change to the extracted `BridgeAI_Project` folder:
   `cd "C:\path\to\BridgeAI_Project"`
3. Use Python 3.10–3.13. Create and activate a virtual environment:
   `python -m venv .venv`
   `.venv\\Scripts\\activate`
4. Install dependencies:
   `python -m pip install --upgrade pip`
   `python -m pip install -r requirements.txt`
5. Run the automated tests:
   `python -m pytest -q`
6. Start the application:
   `python -m streamlit run app.py`
7. Open the local URL printed in the terminal (normally `http://localhost:8501`). Keep the terminal open while using the app.

## Six learning modules
1. Python functions, profile validation, pandas/NumPy analytics, and study planning.
2. Breadth-First Search (BFS) and Dijkstra prerequisite-route demonstrations.
3. Transparent IF–THEN skill advice, Logistic Regression, and Random Forest classification.
4. Feed-forward neural-network demonstration using scikit-learn `MLPClassifier`.
5. Bayes' theorem posterior-probability calculator.
6. TF-IDF + Logistic Regression intent-classification chatbot.

## Observed model demonstration results
The fixed-seed synthetic-data runs reproduced during this review returned:

| Model | Accuracy | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| Logistic Regression | 0.700 | 0.773 | 0.567 | 0.654 |
| Random Forest | 0.833 | 0.917 | 0.733 | 0.815 |

The MLP demonstration returned test accuracy `0.900`, loss `0.0720`, and hidden layers `[12, 6]` at 700 iterations. **Important:** scikit-learn emitted a `ConvergenceWarning`: the optimizer reached the 700-iteration limit before convergence. The output is therefore an educational demonstration, not a fully converged model. Results can vary with library versions.

## Limitations
- The machine-learning examples use a small synthetic teaching dataset; the scores do not establish real-world predictive performance.
- The chatbot is a small intent classifier, not a generative LLM.
- Graph weights and advice rules are illustrative.
- Profile data is stored locally in `data/student_profile.json` on the computer where the app is run.
- The application does not predict or guarantee admission, employment, or placement outcomes.

## Evidence and academic integrity
The `screenshots/` folder contains 11 screenshots supplied with the project. They are evidence of the demonstrated interface, but do not replace running the application on the submission computer. Understand the modules and be prepared to explain the synthetic data, model metrics, and MLP convergence warning during evaluation. Check the institution's latest submission format and exact rubric before submitting.
