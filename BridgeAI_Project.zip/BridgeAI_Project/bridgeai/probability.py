def bayes_posterior(prior,likelihood,false_positive):
    for value in (prior,likelihood,false_positive):
        if not 0<=float(value)<=1: raise ValueError("Probabilities must be between 0 and 1.")
    denominator=prior*likelihood+(1-prior)*false_positive
    return 0.0 if denominator==0 else prior*likelihood/denominator
