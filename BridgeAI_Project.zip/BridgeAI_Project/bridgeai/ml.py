def _dataset():
    from sklearn.datasets import make_classification
    from sklearn.model_selection import train_test_split
    X,y=make_classification(n_samples=240,n_features=8,n_informative=5,n_redundant=1,random_state=42)
    return train_test_split(X,y,test_size=.25,random_state=42,stratify=y)
def train_classifiers():
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import accuracy_score,precision_score,recall_score,f1_score
    Xtr,Xte,ytr,yte=_dataset()
    rows=[]
    for model in [LogisticRegression(max_iter=1000),RandomForestClassifier(n_estimators=80,random_state=42)]:
        model.fit(Xtr,ytr); pred=model.predict(Xte)
        rows.append({"Model":type(model).__name__,"Accuracy":round(accuracy_score(yte,pred),3),
                     "Precision":round(precision_score(yte,pred,zero_division=0),3),
                     "Recall":round(recall_score(yte,pred,zero_division=0),3),
                     "F1":round(f1_score(yte,pred,zero_division=0),3)})
    return rows
def train_neural_network():
    from sklearn.neural_network import MLPClassifier
    from sklearn.metrics import accuracy_score
    Xtr,Xte,ytr,yte=_dataset()
    model=MLPClassifier(hidden_layer_sizes=(12,6),max_iter=700,random_state=42)
    model.fit(Xtr,ytr)
    return {"model":"MLPClassifier feed-forward neural network","hidden_layers":[12,6],
            "iterations":int(model.n_iter_),"test_accuracy":round(float(accuracy_score(yte,model.predict(Xte))),3),
            "loss":round(float(model.loss_),4),"note":"Synthetic teaching dataset; scores are illustrative only. The optimizer reached the 700-iteration limit before convergence; treat this result as a demonstration, not a fully converged model."}
