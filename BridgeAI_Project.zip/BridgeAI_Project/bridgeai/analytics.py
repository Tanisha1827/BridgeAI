import numpy as np
def descriptive_stats(values):
    arr=np.asarray(list(values),dtype=float)
    if arr.size==0: return {"count":0,"mean":0.0,"median":0.0,"minimum":0.0,"maximum":0.0}
    return {"count":int(arr.size),"mean":float(arr.mean()),"median":float(np.median(arr)),
            "minimum":float(arr.min()),"maximum":float(arr.max())}
def make_week_plan(topics,total_hours):
    topics=[str(t).strip() for t in topics if str(t).strip()]
    if not topics: return []
    each=round(float(total_hours)/len(topics),2)
    plan=[[t,each] for t in topics]
    plan[-1][1]=round(float(total_hours)-sum(r[1] for r in plan[:-1]),2)
    return plan
