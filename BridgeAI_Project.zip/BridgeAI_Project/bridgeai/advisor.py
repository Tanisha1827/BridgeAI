def skill_gap_advice(python_level,statistics_level):
    actions=[]
    rules=[
      (python_level=="Beginner","Start with variables, data types, conditions, loops, and small Python exercises."),
      (python_level=="Developing","Practise functions, lists, dictionaries, and pandas data handling."),
      (python_level=="Confident","Build a documented Python project using a dataset."),
      (statistics_level=="Beginner","Revise mean, median, probability, distributions, and graphs."),
      (statistics_level=="Developing","Practise sampling, correlation, and model evaluation metrics."),
      (statistics_level=="Confident","Apply statistical reasoning to a dataset and explain uncertainty.")
    ]
    for condition,advice in rules:
        if condition: actions.append(advice)
    return {"summary":"These transparent IF–THEN suggestions are based only on the confidence levels selected.","actions":actions}
