import json
from pathlib import Path
PROFILE_PATH=Path("data/student_profile.json")
def validate_profile(profile):
    if not isinstance(profile.get("name",""),str): return False,"Name must be text."
    try: hours=int(profile.get("hours",0))
    except (TypeError,ValueError): return False,"Study hours must be a whole number."
    if not 1<=hours<=60: return False,"Weekly study hours must be between 1 and 60."
    return True,"Profile is valid."
def save_profile(profile):
    PROFILE_PATH.parent.mkdir(parents=True,exist_ok=True)
    PROFILE_PATH.write_text(json.dumps(profile,indent=2),encoding="utf-8")
def load_profile():
    if PROFILE_PATH.exists(): return json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    return {"name":"","background":"Life Sciences","goal":"AI foundations","hours":8}
