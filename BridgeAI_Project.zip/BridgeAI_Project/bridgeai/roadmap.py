from collections import deque
import heapq
def bfs(graph,start,goal):
    queue=deque([(start,[start])]); visited={start}
    while queue:
        node,path=queue.popleft()
        if node==goal: return path
        for nxt in graph.get(node,[]):
            if nxt not in visited: visited.add(nxt); queue.append((nxt,path+[nxt]))
    return []
def dijkstra(graph,start,goal):
    heap=[(0,start,[start])]; best={}
    while heap:
        cost,node,path=heapq.heappop(heap)
        if node in best: continue
        best[node]=cost
        if node==goal: return {"path":path,"cost":cost}
        for nxt,weight in graph.get(node,{}).items():
            if weight<0: raise ValueError("Dijkstra requires non-negative edge weights.")
            if nxt not in best: heapq.heappush(heap,(cost+weight,nxt,path+[nxt]))
    return {"path":[],"cost":float("inf")}
