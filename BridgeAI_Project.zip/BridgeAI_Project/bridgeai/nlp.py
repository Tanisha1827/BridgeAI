def train_chatbot():
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    texts=[
      "make a study plan","help me schedule study hours","how should I study this week",
      "how to learn python","I am weak in statistics","what skills should I learn first",
      "suggest an AI project","give me a project idea","how can I build a beginner project",
      "hello","thank you","good morning"
    ]
    labels=["planning"]*3+["skills"]*3+["project"]*3+["greeting"]*3
    vectorizer=TfidfVectorizer(ngram_range=(1,2),stop_words="english")
    X=vectorizer.fit_transform(texts)
    model=LogisticRegression(random_state=42,max_iter=500).fit(X,labels)
    return model,vectorizer
def chatbot_reply(text,model,vectorizer):
    category=model.predict(vectorizer.transform([text]))[0]
    responses={
      "planning":"Break your goal into small topics, assign realistic weekly hours, and review progress at the end of the week.",
      "skills":"Build foundations in sequence: Python basics, data handling, statistics, then introductory machine learning.",
      "project":"Choose a small student problem, define the scope, use clearly labelled data, build a baseline, and document limitations.",
      "greeting":"Hello! I can help with study planning, skill foundations, and beginner project ideas."
    }
    return responses[category]
