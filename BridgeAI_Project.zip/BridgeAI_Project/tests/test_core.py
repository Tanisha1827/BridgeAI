from bridgeai.analytics import descriptive_stats,make_week_plan
from bridgeai.roadmap import bfs,dijkstra
from bridgeai.probability import bayes_posterior
from bridgeai.advisor import skill_gap_advice
from bridgeai.profile import validate_profile
def test_stats(): assert descriptive_stats([2,4,6])["mean"]==4
def test_empty_stats(): assert descriptive_stats([])["count"]==0
def test_plan_total(): assert round(sum(x[1] for x in make_week_plan(["a","b","c"],9)),2)==9
def test_empty_plan(): assert make_week_plan([],4)==[]
def test_bfs(): assert bfs({"a":["b"],"b":["c"]},"a","c")==["a","b","c"]
def test_bfs_unreachable(): assert bfs({"a":["b"]},"a","z")==[]
def test_dijkstra(): assert dijkstra({"a":{"b":2},"b":{"c":3}},"a","c")["cost"]==5
def test_dijkstra_unreachable(): assert dijkstra({"a":{"b":1}},"a","z")["path"]==[]
def test_bayes(): assert round(bayes_posterior(.5,.8,.2),2)==.8
def test_bayes_range(): assert 0<=bayes_posterior(.2,.7,.1)<=1
def test_rules(): assert len(skill_gap_advice("Beginner","Beginner")["actions"])==2
def test_profile_valid(): assert validate_profile({"name":"Student","hours":8})[0]
def test_profile_invalid_hours(): assert not validate_profile({"name":"Student","hours":0})[0]
