Capture genuine screenshots from the running BridgeAI application and save them here. No fabricated screenshots are included.
