import streamlit as st
import pandas as pd
from bridgeai.profile import validate_profile, save_profile, load_profile
from bridgeai.analytics import descriptive_stats, make_week_plan
from bridgeai.advisor import skill_gap_advice
from bridgeai.roadmap import bfs, dijkstra
from bridgeai.ml import train_classifiers, train_neural_network
from bridgeai.probability import bayes_posterior
from bridgeai.nlp import train_chatbot, chatbot_reply

st.set_page_config(page_title="BridgeAI", page_icon="🌉", layout="wide")
st.title("🌉 BridgeAI")
st.subheader("Student Skill-Gap & Career Pathway Companion")
st.caption("An educational prototype for learners building foundations in AI and technology.")
page=st.sidebar.radio("Navigate", ["Home","My Profile","Study Planner & Analytics","Skill Gap & Roadmap","AI Learning Lab","AI Study Companion","About & Evidence"])
if page=="Home":
    st.write("BridgeAI brings together study planning, explainable learning advice, prerequisite search, introductory machine learning, probability, and a study chatbot.")
    a,b,c=st.columns(3); a.metric("Core modules","6"); b.metric("Learning approach","Explainable"); c.metric("Profile storage","Local")
    st.info("This prototype supports learning. It is not a validated career, admission, or placement prediction system.")
elif page=="My Profile":
    p=load_profile()
    name=st.text_input("Name",p.get("name",""))
    background=st.selectbox("Academic background",["Life Sciences","Commerce","Arts","Computer Science","Other"])
    goal=st.selectbox("Learning goal",["AI foundations","Data analytics","Machine learning","Software development","Explore options"])
    hours=st.number_input("Weekly study hours",1,60,int(p.get("hours",8)))
    if st.button("Save profile"):
        ok,msg=validate_profile({"name":name,"hours":hours})
        if ok: save_profile({"name":name,"background":background,"goal":goal,"hours":hours}); st.success("Profile saved on this computer.")
        else: st.error(msg)
elif page=="Study Planner & Analytics":
    topics=st.text_input("Topics (comma-separated)","Python basics, Statistics, Data handling, Machine learning")
    hours=st.slider("Available weekly hours",2,40,8)
    if st.button("Generate study plan"):
        plan=make_week_plan([x.strip() for x in topics.split(",") if x.strip()],hours)
        st.dataframe(pd.DataFrame(plan,columns=["Topic","Suggested hours"]),use_container_width=True)
        st.write("Descriptive statistics:",descriptive_stats([x[1] for x in plan]))
elif page=="Skill Gap & Roadmap":
    python_level=st.select_slider("Python confidence",["Beginner","Developing","Confident"])
    stats_level=st.select_slider("Statistics confidence",["Beginner","Developing","Confident"])
    advice=skill_gap_advice(python_level,stats_level)
    st.write(advice["summary"])
    for x in advice["actions"]: st.write("• "+x)
    graph={"Python":["Data handling"],"Data handling":["Statistics"],"Statistics":["Machine learning"],"Machine learning":["AI project"]}
    start=st.selectbox("Starting topic",list(graph))
    goal=st.selectbox("Target topic",["Data handling","Statistics","Machine learning","AI project"])
    st.write("BFS route:", " → ".join(bfs(graph,start,goal)) or "No route found")
    weighted={"Python":{"Data handling":1},"Data handling":{"Statistics":2},"Statistics":{"Machine learning":2},"Machine learning":{"AI project":3}}
    st.write("Dijkstra route:",dijkstra(weighted,start,goal))
elif page=="AI Learning Lab":
    st.markdown("#### Supervised classification")
    if st.button("Train Logistic Regression and Random Forest"):
        st.dataframe(pd.DataFrame(train_classifiers()),use_container_width=True)
    st.markdown("#### Feed-forward neural network")
    if st.button("Train MLP neural network"):
        result=train_neural_network()
        st.json(result)
    st.markdown("#### Bayes' theorem")
    prior=st.slider("Prior P(A)",0.01,0.99,0.30)
    likelihood=st.slider("P(Evidence | A)",0.01,0.99,0.80)
    false_positive=st.slider("P(Evidence | not A)",0.01,0.99,0.10)
    st.metric("Posterior P(A | Evidence)",f"{bayes_posterior(prior,likelihood,false_positive):.2%}")
elif page=="AI Study Companion":
    question=st.text_input("Ask BridgeAI about study plans, skills, or projects")
    if st.button("Ask"):
        model,vectorizer=train_chatbot()
        st.write(chatbot_reply(question,model,vectorizer))
elif page=="About & Evidence":
    st.write("Core topics: Python functions, validation, pandas/NumPy analytics, BFS, Dijkstra, transparent IF–THEN rules, Logistic Regression, Random Forest, MLP neural network, Bayes' theorem, and TF-IDF intent classification.")
    st.warning("The model examples use small synthetic teaching data. Capture genuine screenshots after running the app; none are fabricated or pre-filled.")
