# BridgeAI — Student Skill-Gap & Career Pathway Companion

## Abstract
BridgeAI is a student-focused educational prototype combining study planning, transparent skill advice, prerequisite search, introductory machine learning, probability, and an intent-based chatbot.

## Problem statement
Learners entering AI from varied academic backgrounds may need a structured way to identify foundational learning areas and organise study time.

## Objectives
- Validate a basic learner profile.
- Allocate weekly study hours across topics and calculate descriptive statistics.
- Provide transparent IF–THEN skill suggestions.
- Demonstrate BFS and Dijkstra.
- Compare Logistic Regression and Random Forest.
- Demonstrate a feed-forward neural network using MLPClassifier.
- Calculate a Bayes posterior probability.
- Classify chatbot intents using TF-IDF and Logistic Regression.

## Technology
Python, Streamlit, pandas, NumPy, scikit-learn, pytest, and local JSON storage.

## Methodology
The learner enters profile and study details. The application validates profile fields, allocates available study hours, provides rule-based recommendations, searches a prerequisite graph, and runs educational model demonstrations on synthetic data.

## Module descriptions
1. **Python and analytics:** modular functions, validation, descriptive statistics, and weekly planning.
2. **Search algorithms:** BFS for unweighted traversal and Dijkstra for minimum-cost routes with non-negative weights.
3. **Rules and classification:** explainable IF–THEN advice plus Logistic Regression and Random Forest evaluation.
4. **Neural network:** MLPClassifier with two hidden layers.
5. **Probability:** Bayes' theorem posterior calculator.
6. **NLP chatbot:** TF-IDF feature extraction and Logistic Regression intent classification.

## Observed model demonstration results
The fixed-seed synthetic-data run reproduced in the review environment returned:

| Model | Accuracy | Precision | Recall | F1 |
|---|---:|---:|---:|---:|
| Logistic Regression | 0.700 | 0.773 | 0.567 | 0.654 |
| Random Forest | 0.833 | 0.917 | 0.733 | 0.815 |

The MLPClassifier used hidden layers `[12, 6]` and a 700-iteration limit; the reproduced run returned test accuracy `0.900` and loss `0.0720`. It also emitted a `ConvergenceWarning` because the iteration limit was reached before convergence. This is disclosed rather than presented as a fully converged model. All results are illustrative and based on synthetic data.

## Testing and verification
- ZIP archive integrity: passed.
- Python syntax compilation: all 10 included Python files passed.
- Automated unit tests: 13 passed in the review environment (`python -m pytest -q`).
- Model smoke test: Logistic Regression, Random Forest, and MLP training functions executed and returned the results above.
- DOCX and PPTX files: opened and their text content was inspected during review.
- The review environment did not have Streamlit installed, so a fresh Streamlit UI launch was not independently verified in this review. The user had previously reported running the app and supplied screenshots; that laptop execution is user-reported evidence, not a fresh execution by this reviewer.
- The exact official Smart ED rubric was not present in the reviewed ZIP, so exact rubric compliance cannot be certified from this package alone.

## Limitations
Synthetic data is used for repeatable teaching demonstrations and does not establish real-world model performance. The chatbot is not a generative AI assistant. Recommendation rules are simple and transparent. The application does not guarantee career outcomes.

## Future scope
A larger consent-based dataset, validated recommendation evaluation, accessibility improvements, secure multi-user storage, and richer analytics could be explored.

## Conclusion
BridgeAI demonstrates a coherent set of foundational AI and programming concepts through a single student-oriented application.
